import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Konfigurasi halaman
st.set_page_config(page_title="Simulasi Statistik Deskriptif", layout="wide")

st.title("📊 Aplikasi Simulasi Statistik Deskriptif")
st.write("Upload file CSV atau masukkan data nilai manual untuk dianalisis.")

# === Upload File CSV ===
uploaded_file = st.file_uploader("Upload file CSV (harus ada kolom 'nilai')", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    if 'nilai' not in df.columns:
        st.error("Kolom 'nilai' tidak ditemukan dalam file CSV.")
        data = None
    else:
        data = df['nilai']
else:
    input_manual = st.text_area("Masukkan data nilai (pisahkan dengan koma)", 
                                 "78,85,90,88,70,65,80,85,95,92,85,75,60,88,78,82,84,90,77,70,85,89,80,74,82,90,85,73,60,78")
    try:
        data = pd.Series([float(x.strip()) for x in input_manual.split(',') if x.strip() != ""])
    except ValueError:
        st.error("Format angka salah! Pastikan hanya angka yang dipisah dengan koma.")
        data = None

# === Analisis Statistik ===
if data is not None and len(data) > 0:
    st.subheader("📈 Hasil Statistik Deskriptif")
    st.write(f"**Jumlah Data:** {len(data)}")

    st.write(f"**Mean (Rata-rata):** {np.mean(data):.2f}")
    st.write(f"**Median:** {np.median(data):.2f}")
    st.write(f"**Modus:** {data.mode().tolist()}")
    st.write(f"**Varians:** {np.var(data, ddof=1):.2f}")
    st.write(f"**Standar Deviasi:** {np.std(data, ddof=1):.2f}")

    st.subheader("📊 Visualisasi")

    fig, ax = plt.subplots(1, 2, figsize=(14, 5))

    sns.histplot(data, bins=10, kde=True, ax=ax[0], color='skyblue')
    ax[0].set_title("Histogram Nilai")
    ax[0].set_xlabel("Nilai")
    ax[0].set_ylabel("Frekuensi")

    sns.boxplot(data=data, ax=ax[1], color='lightgreen')
    ax[1].set_title("Boxplot Nilai")

    st.pyplot(fig)
