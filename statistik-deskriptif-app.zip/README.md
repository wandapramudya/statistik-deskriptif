# Aplikasi Simulasi Statistik Deskriptif

Aplikasi berbasis Streamlit untuk menghitung dan memvisualisasikan statistik deskriptif dari data nilai mahasiswa.

## Fitur:
- Hitung: Mean, Median, Modus, Varians, Standar Deviasi
- Upload CSV atau input manual
- Histogram dan Boxplot

## Cara Menjalankan:
```
pip install -r requirements.txt
streamlit run app.py
```
